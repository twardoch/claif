"""Test suite for claif core framework."""
